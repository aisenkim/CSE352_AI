class Node:
    def __init__(self, value: int, color: int):
        self.value = value
        self.color = color

