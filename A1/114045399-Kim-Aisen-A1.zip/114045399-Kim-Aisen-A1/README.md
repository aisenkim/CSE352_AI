**Python Version: 3.8**
</br>
**Files Needed**</br>
`1. Heuristics.py` </br>
`2. puzzleGenerator.py`</br>
`3. puzzleSolver.py` </br>
`4. TileProblem.py`


